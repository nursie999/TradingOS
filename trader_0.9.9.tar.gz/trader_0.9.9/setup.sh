#!/bin/bash

project_dir=$(pwd)

if [ "$EUID" -ne 0 ]
  then echo "Please run as root"
  exit
fi

apt update

echo "install python and pip"
apt install python3 -y
apt install python3-pip -y

echo "install talib"
if [ ! -f "/usr/bin/ta-lib-config" ]; then
  wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
  tar -xzf ta-lib-0.4.0-src.tar.gz
  cd ta-lib/
  ./configure --prefix=/usr
  make
  make install
  cd project_dir
  rm ta-lib-0.4.0-src.tar.gz
  rm -rf ta-lib
fi

pip install ta-lib

echo "install flask"
pip install flask

pip install flask-mqtt

echo "install pandas"
pip install pandas

echo "install shortuuid"
pip install shortuuid

echo "install supervisor"
apt install supervisor -y
systemctl start supervisor

cat>/etc/supervisor/conf.d/trader.conf<<EOF
[program:trader]
command = python3 main.pyc ; 
directory = $project_dir ;
autostart = true ; 
startsecs = 5 ; 
autorestart = true ; 
startretries = 3 ; 
user = root ; 
redirect_stderr = true ; 
stdout_logfile_maxbytes = 20MB ; 
stdout_logfile_backups = 20 ; 
stdout_logfile = $project_dir/logs/trader.log ;
;environment=PATH=$PATH:$project_dir
EOF

supervisorctl update
supervisorctl start trader


